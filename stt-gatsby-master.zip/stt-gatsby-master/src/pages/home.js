import React from "react"

// import "../components/menu.css"
// import "../components/bootstrap.min.css"
// import "../components/hero-slider-style.css"
// import "../components/magnific-popup.css"
// import "../components/templatemo-style.css"

import Menu from "../components/menu2"

const Home = () => {
  return <Menu />
}

export default Home
